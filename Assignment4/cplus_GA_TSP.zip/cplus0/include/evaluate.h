/*
 * evaluate.h
 *
 *  Created on: Mar 15, 2016
 *      Author: sushil
 */

#ifndef EVALUATE_H_
#define EVALUATE_H_

#include <individual.h>
#include <cstring>
#include <const.h>

void evaluate(ga::Individual *ent);
void xSquared(ga::Individual *ent);
void convertToString(int *vec, int size, char *chrom);

void dejong_First(ga::Individual *ent);
void dejong_Second(ga::Individual *ent);
void dejong_Third(ga::Individual *ent);
void dejong_Fourth(ga::Individual *ent);
void dejong_Fifth(ga::Individual *ent);
void TSP_distance(ga::Individual *ent, float dist_matrix[500][500] );
#endif /* EVALUATE_H_ */
