#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <math.h>
#include <assert.h>
#include <stdio.h>
#include <fstream>
#include <algorithm>
#include <limits>

#include <stdlib.h>
#include <assert.h>
#include <iostream>
#include <algorithm>
using namespace std;




int main(){
	int a[10]= {9,8,4,5,6,7,1,3,2,10};
	int b[10]= {8,7,1,2,3,10,9,5,4,6};
	int temp;
	int a_temp[10];
	int b_temp[10];
	int i=0,j=0;

    int max=9,min=0;
	int t1 = rand()%(max-min + 1) + min;
	int t2 = rand()%(max-min + 1) + min;
	int xp1 = std::min(t1, t2);
	int xp2 = std::max(t1, t2);

	cout<<"Before PMX: "<<endl;
	cout<<"A: "<<endl;
	for(i=0;i<10;i++){
      cout<<a[i]<<"\t";

	}
    cout<<"B: "<<endl;
	for(i=0;i<10;i++){
      cout<<b[i]<<"\t";

	}


    for(i=0;i<10;i++){
    	a_temp[i] = a[i];
    	b_temp[i] = b[i];

    }
	for(i = xp1; i< xp2; i++){
		temp = a[i];
		a[i] = b[i];
		b[i] = temp;
	}



	for(i=0;i<xp1;i++){
        for(j=xp1;j<xp2;j++){
	        if(a[i] == a[j]){
                a[i] = a_temp[j];
            } 
	        if(b[i] == b[j]){;
                b[i] = b_temp[j];
	        } 
        }          
     }

     for(i=xp2;i<10;i++){
        for(j=xp1;j<xp2;j++){
	        if(a[i] == a[j]){
                a[i] = a_temp[j];
            } 
	        if(b[i] == b[j]){;
                b[i] = b_temp[j];
	        } 
        }          
     }
	
	cout<<"\nAfter PMX: "<<endl;
	cout<<"A: "<<endl;
	for(i=0;i<10;i++){
      cout<<a[i]<<"\t";

	}
    cout<<"\nB: "<<endl;
	for(i=0;i<10;i++){
      cout<<b[i]<<"\t";

	}
    






   return 0;
}




