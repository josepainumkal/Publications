import os

listFiles = [filename for filename in os.listdir('/home/jpainumkal/Downloads/cplus/src/d1_01/') if filename.startswith("outfile_")]
print listFiles

sumofFitness=0
opfile = open('d3_01.txt', 'w')

for gen in range(0,50):
    opfile.write(str(gen)+"\t")
    for fit_val in range (1,4):
        for file in listFiles:
            lines = open('/home/jpainumkal/Downloads/cplus/src/d3_01/'+file,'r').readlines()
            values=lines[gen].split('\t')
          
            sumofFitness=sumofFitness+float(values[fit_val])

        sumofFitness=sumofFitness/len(listFiles)
        opfile.write(str(sumofFitness)+"\t\t")
        sumofFitness=0
    opfile.write("\n")



#plotting the graph
# import matplotlib.pyplot as plt
# x1 =[]
# y1=[]
# x2 =[]
# y2=[]
# x3 =[]
# y3=[]
# file = 'd1_03.txt'
# lines = open('/home/jpainumkal/Downloads/cplus/src/'+file,'r').readlines()

# for gen in range(0,50):
#     values=lines[gen].split('\t')
#     x1.append(float(values[0]))
#     y1.append(float(values[1]))
#     x2.append(float(values[0]))
#     y2.append(float(values[3]))
#     x3.append(float(values[0]))
#     y3.append(float(values[5]))

# # print x
# # print y


# plt.plot(x1,y1, 'g')
# plt.plot(x2,y2, 'r')
# plt.plot(x3,y3, 'c')

# plt.xlabel('Evaluations')
# plt.ylabel('Fitness')
# plt.title('Crossover Probability (0.99) and Mutation Probability (0.01)')
# plt.plot(x1,y1, label='Minimum')
# plt.plot(x2,y2, label='Average')
# plt.plot(x3,y3, label='Maximum')
# # plt.xlim([0, 1])
# # plt.ylim([0, 3000])

# plt.legend()
# plt.show()


