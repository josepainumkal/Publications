/*
 * individual.cpp
 *
 *  Created on: Feb 3, 2016
 *      Author: sushil
 */

#include <individual.h>
#include <stdlib.h>
#include <random.h>
#include <assert.h>
#include <iostream>
#include <algorithm>
#include <const.h>
#include <math.h>

using namespace std;
using namespace ga;

Individual::Individual(){
	length    = 0;
	setup();
}

Individual::Individual(int len){
	length = len;
	setup();
}

void Individual::setup(){
	for(int i = 0; i < length; i++){
		this->chrom[i] = -1;
	}
}


void Individual::init(int len){
	assert(len <= MAX_CHROM_LENGTH);
	length = len;
	// for(int i = 0; i < length; i++){
	// 	this->chrom[i] = flip(0.5);
	// }
    
    // random shuffle
    int city[300], c=1;

    for(int i=0;i<length;i++){
    	city[i] = c;
    	c++;
    }
    random_shuffle(&city[0], &city[length]);

    //cout<<"\nMy Individual Length: "<<length<<endl;
    for(int i = 0; i < length; i++){
		this->chrom[i] = city[i];
		
		//cout<<chrom[i]<<"\t";

	}
	//cout<<"\n";

}


void Individual::mutate(float prob){
	int randNum =0;
    int max = GRAPH_LENGTH -1;
    int min = 0;
    int temp =0;


	for(int i = 0; i < length; i++){
		// if(flip(prob) == 1)
		// 	chrom[i] = 1 - chrom[i];
        if(flip(prob) == 1){
        	randNum = rand()%(max-min + 1) + min;
        	//normal swap
        	// temp = this->chrom[i];
        	// this->chrom[i] =  this->chrom[randNum];
        	// this->chrom[randNum] = temp;

        	//inversion mutation
        	int start = std::min(i, randNum);
	        int end = std::max(i, randNum);
	        int mid = (end-start)/2;
	        int q=end, k=0;

        	for(k=start; k<=mid;k++){
	            temp = this->chrom[k];
	        	this->chrom[k] =  this->chrom[q];
	        	this->chrom[q] = temp;
	        	q--;
        	}
        }
	}
}


void Individual::copy(Individual *ip){
	assert(ip->length <= MAX_CHROM_LENGTH);
	this->length = ip->length;
	for(int i = 0; i < length; i++){
		this->chrom[i] = ip->chrom[i];
	}
	for(int i = 0; i < MAX_CRITERIA; i++){
		this->fitness[i] = ip->fitness[i];
		this->objectives[i] = ip->objectives[i];
	}
	this->fit = ip->fit;
	this->scaledFit = ip->scaledFit;
}

