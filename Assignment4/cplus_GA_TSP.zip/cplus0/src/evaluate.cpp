/*
 * evaluate.cpp
 *
 *  Created on: Feb 3, 2016
 *      Author: sushil
 */

#include <evaluate.h>
#include <utils.h>
#include <const.h>

#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <assert.h>
#include <const.h>

using namespace std;

void evaluate(ga::Individual *ent){
//	cout << *ent << endl;
	double sum = 0;
	for(int i = 0; i < ent->length; i++){
		sum += ent->chrom[i];
	}
	ent->fit = sum;
	for(int i = 0; i < ga::MAX_CRITERIA; i++){
		ent->fitness[i] = sum;
	}

//	cout << "----------------------------------------" << endl;

}

double decode(int * chrom, int start, int end){
  double prod = 0;
  for (int i = start; i < end; i++){
    prod += (chrom[i] == 0 ? 0 : pow(2.0, (double) i));
  }
  return prod;
}
void xSquared(ga::Individual *ent) {
  int value = decode(ent->chrom, 0, ent->length);
  ent->fit = value * value;
  return;

}

void TSP_distance(ga::Individual *ent, float dist_matrix[500][500] ){

 //cout<<"Dist-Matrix: "<<endl;
// for(int i=1;i<=ga::GRAPH_LENGTH;i++){
 //   for(int j=1;j<=ga::GRAPH_LENGTH;j++){
 //       cout<<dist_matrix[i][j]<<"\t";
 //    }
 //    cout<<'\n';
 //}

	int start = 0;
	int end = ent->length;
 
  int i=0;
  double tsp_distance =0;


     cout<<"\nPopulation: "<<endl;
     for(int i = 0; i < end; i++){
		   cout<<ent->chrom[i]<<"\t";
	   }
	   cout<<"\n";


    i=start;
    while(i<(end - 1)){
      //cout<<"Distance between "<< ent->chrom[i] <<" and "<< ent->chrom[i+1] <<" is "<< dist_matrix[ent->chrom[i]][ent->chrom[i+1]]<<endl;
      tsp_distance = tsp_distance + dist_matrix[ent->chrom[i]][ent->chrom[i+1]];
      i++;
    }
    ent->fit = tsp_distance;
    ent->fit = (1/(ent->fit));
    cout << "------------Fitness(tsp_distance)--------------------:"<< ent->fit << endl;
    return;
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

double decode_dejong(int * chrom, int start, int end){
  double prod = 0;
  for (int i = start; i < end; i++){
    prod += (chrom[i] == 0 ? 0 : pow(2.0, (double) i-start));
  }
  return prod;
}



void dejong_First(ga::Individual *ent){
	double val1 =  (decode_dejong(ent->chrom, 0, 10)-512)/100;
	double val2 =  (decode_dejong(ent->chrom, 10, 20)-512)/100;
	double val3 =  (decode_dejong(ent->chrom, 20, 30)-512)/100;
    ent->fit = (val1*val1)+ (val2*val2) + (val3*val3);
    ent->fit = 1/(ent->fit);

    return;
}

void dejong_Second(ga::Individual *ent){
	double val1 =  (decode_dejong(ent->chrom, 0, 12)-2048)/1000;
	double val2 =  (decode_dejong(ent->chrom, 12, 24)-2048)/1000;
	double val_i =  (decode_dejong(ent->chrom, 24, 36)-2048)/1000;

    double firstTerm = ((val1*val1) - val2)*((val1*val1) - val2);
    double secondTerm = (1-val_i)*(1-val_i);
    ent->fit = (100*(firstTerm)) + secondTerm;
    ent->fit = 1/(ent->fit);
    return;
}

void dejong_Third(ga::Individual *ent){
	int val1 =  (decode_dejong(ent->chrom, 0, 10)-512)/100;
    ent->fit = int(val1 * 5);

    if(ent->fit!=0)
       ent->fit = 1/(ent->fit);
    //cout<<ent->fit;
    return;
}

void dejong_Fourth(ga::Individual *ent){
	double val1 =  (decode_dejong(ent->chrom, 0, 8)-256)/100;
    double xTerm = val1*val1*val1*val1;

    //gauss noise
    double pi = 22/7;
    double eTerm = pow(2.71828, (-1*(val1*val1))/2);
    double gaussTerm = (1/sqrt(2*pi))*(eTerm);
    double fitness=0;

    for(int i=1;i<=30;i++){
        fitness=fitness+(i*xTerm);
        fitness = fitness+gaussTerm;

    }

    //fitness = fitness+gaussTerm;


    ent->fit = fitness;

    if(ent->fit!=0)
       ent->fit = 1/(ent->fit);
    return;
}


//form the distance matrix here, for calulating fitness

