import os

listFiles = [filename for filename in os.listdir('/home/jpainumkal/Downloads/cplus/src/testCopy/dejongFirst') if filename.startswith("outfile")]

#listFiles=["1.txt","2.txt"]
sumofFitness=0

opfile = open('d1_cm1.txt', 'w')

for gen in range(0,50):
    opfile.write(str(gen)+"\t")
    for fit_val in range (1,4):
        for file in listFiles:
            lines = open(file,'r').readlines()
            values=lines[gen].split('\t')
            #print values[1]
            sumofFitness=sumofFitness+float(values[fit_val])

        sumofFitness=sumofFitness/len(listFiles)
        opfile.write(str(sumofFitness)+"\t\t")
        sumofFitness=0
    opfile.write("\n")











