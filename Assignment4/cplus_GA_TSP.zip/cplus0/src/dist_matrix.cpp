    float tsp_x[GRAPH_LENGTH];
	float tsp_y[GRAPH_LENGTH];
	//float dist_matrix[GRAPH_LENGTH][GRAPH_LENGTH];
    std::ifstream input("tsplib_data/eil51.txt");
	std::string line;
    int a, b, c, i=1;
	while (input >> a >> b >> c){
		//std::cout<<"a: "<<a<<"\tb: "<<b<<"\tc: "<<c<<endl; 
		tsp_x[i]=b;
		tsp_y[i]=c;
        i++;
    }

    cout<<"Data from file: "<<endl;
    cout<<"City\tX\tY\n";
    for(int i=1;i<=GRAPH_LENGTH;i++){
    	cout<<i<<"\t"<<tsp_x[i]<<"\t"<<tsp_y[i]<<"\n";
    }


    for(int i=0;i<=5;i++){
		for(int j=0;j<=5;j++){
		   options.dist_matrix[i][j] = 0;
		}
	}

    for(int i=1;i<=5;i++){
		for(int j=1;j<=5;j++){
			if(i==j){
               //dist_matrix[i][j]=0;
				options.dist_matrix[i][j] = 0;
			}else{
				//dist_matrix[i][j] = 
				options.dist_matrix[i][j] = calculateDistance(tsp_x[i],tsp_y[i],tsp_x[j],tsp_y[j]);
			}
		}

	}

    cout<<"DIST-MATRIX At ga.cpp"<<endl;
	for(int i=1;i<=5;i++){
    	for(int j=1;j<=5;j++){
    		cout<<options.dist_matrix[i][j]<<"\t";
    	}
    	cout<<'\n';
    }




