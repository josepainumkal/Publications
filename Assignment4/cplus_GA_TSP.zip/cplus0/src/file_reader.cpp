#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <math.h>

using namespace std;

const int GRAPH_LENGTH = 51;
float tsp_x[GRAPH_LENGTH];
float tsp_y[GRAPH_LENGTH];
float dist_matrix[GRAPH_LENGTH][GRAPH_LENGTH];



float calculateDistance(float x1, float y1, float x2, float y2){
    float xd,yd,dij;
    xd = x1 - x2;
	yd = y1 - y2;
	dij = (int)(sqrt(xd*xd + yd*yd) + 0.5);
	return dij;
}


 float distmatrix(float *tsp_x, float *tsp_y){
	for(int i=0;i<GRAPH_LENGTH;i++){
		for(int j=0;j<GRAPH_LENGTH;j++){
			if(i==j){
               dist_matrix[i][j]=0;
			}else{
				dist_matrix[i][j] = calculateDistance(tsp_x[i],tsp_y[i],tsp_x[j],tsp_y[j]);
			}
		}
	}
}


int main(){
	// std::ifstream input("tsplib_data/eil51.txt");
	// std::string line;

 //    int a, b, c, i=0;
	// while (input >> a >> b >> c){
	// 	//input >> a >> b >>c;	
	// 	std::cout<<"a: "<<a<<"\tb: "<<b<<"\tc: "<<c<<endl; 
	// 	tsp_x[i]=b;
	// 	tsp_y[i]=c;
 //        i++;
 //    }
     
 //    distmatrix(tsp_x, tsp_y);
 
 //    //forming a distance matrix
 //    for(int i=0;i<GRAPH_LENGTH;i++){
 //    	for(int j=0;j<GRAPH_LENGTH;j++){
 //    		cout<<dist_matrix[i][j]<<"\t";
 //    	}
 //    	cout<<'\n';
 //    }



   return 0;
}




