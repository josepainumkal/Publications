//============================================================================
// Name        : ga.cpp
// Author      : Sushil J Louis
// Version     :
// Copyright   : Copyright University of Nevada, Reno
// Description : GA in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <utils.h>
#include <population.h>
#include <ga.h>
#include <random.h>
#include <const.h>

#include <iostream>
#include <sstream>
#include <string>
#include <math.h>

using namespace std;
using namespace ga;
std::ofstream out;


int main(int argc, char *argv[]) {
   int randomSeed = 99;
   for(int i=0;i<30;i++){
       randomSeed = randomSeed+10;

     GA ga = GA(argc, argv, randomSeed);
	 ga.init();

	  ga.run();
	  ga.report();

	  out.open("jose.txt", std::ios::app);
	  out<< i<<"\t"<< 1.0/(ga.bestIndividualSoFar->fit)<<"\n";
	  out.close();

   }
	return 0;
}

GA::GA(int argc, char *argv[], int randomSeed){

	setupOptions(argc, argv, randomSeed);
	srandom(options.randomSeed);
	ofstream ofs(options.outfile, std::ofstream::out | std::ofstream::trunc);
	ofs.close();
	ofstream pofs(options.phenotypeFile, std::ofstream::out | std::ofstream::trunc);
	pofs.close();
	maxFitGen = 0;
	this->bestIndividualSoFar = new Individual(options.chromLength);
	bestFitnessSoFar = -1;


	// cout<<"DIST-MATRIX At  GA::GA Constructor"<<endl;
	// for(int i=1;i<=5;i++){
 //    	for(int j=1;j<=5;j++){
 //    		cout<< options.dist_matrix[i][j]<<"\t";
 //    	}
 //    	cout<<'\n';
 //    }


}

void GA::init(){

	parent = new Population(options);
	child  = new Population(options);
	parent->initialize(); // evaluates, stats, and reports on initial population
	updateProgress(0, parent);
//	cout << "initialized" << endl;
}



//
//void GA::CHC(Population *p, Population *c){
//}

void GA::run(){//chc

	Population *tmp;
	for (unsigned int i = 1; i < options.maxgens; i++){
	  //parent->chc(child);
	    parent->generation(child);
		child->statistics();
		child->report(i);

		updateProgress(i, child);

		tmp = parent;
		parent = child;
		child = tmp;
		//cout << "Generation: " << i << endl;
	}

}

/**
 * Update and save the best ever individual
 */
void GA::updateProgress(unsigned int gen, Population *p){

  if (p->max > bestFitnessSoFar){
    bestFitnessSoFar = p->max;
    maxFitGen = gen;
    bestIndividualSoFar->copy(p->pop[p->maxi]);

    
    char printbuf[1024];
    char chromString[MAX_CHROM_LENGTH+1];
    chromToString(bestIndividualSoFar->chrom, bestIndividualSoFar->length, chromString);
    sprintf(printbuf, "%4i \t %f \t %s\n", maxFitGen, bestFitnessSoFar, chromString);
    writeBufToFile(printbuf, options.phenotypeFile);
  }
  
 // if (p->min < bestFitnessSoFar){
 //    bestFitnessSoFar = p->min;
 //    maxFitGen = gen;
 //    bestIndividualSoFar->copy(p->pop[p->mini]);

    
 //    char printbuf[1024];
 //    char chromString[MAX_CHROM_LENGTH+1];
 //    chromToString(bestIndividualSoFar->chrom, bestIndividualSoFar->length, chromString);
 //    sprintf(printbuf, "%4i \t %f \t %s\n", maxFitGen, bestFitnessSoFar, chromString);
 //    writeBufToFile(printbuf, options.phenotypeFile);
 //  }
}


void GA::report(){
  //parent->report(options.maxgens);
  cout << *(parent->pop[parent->maxi])<<"\t" << endl;
}

void GA::configure(){
	ifstream ifs(options.infile);
	if(ifs.good()){
		ifs >> options.popSize;
		ifs >> options.chromLength;
		ifs >> options.maxgens;
		ifs >> options.px;
		ifs >> options.pm;
		ifs >> options.scaler;
		ifs >> options.lambda;
	}
	ifs.close();
}

float calculateDistance(float x1, float y1, float x2, float y2){
    float xd,yd,dij;
    xd = x1 - x2;
	yd = y1 - y2;
	dij = (int)(sqrt(xd*xd + yd*yd) + 0.5);
	return dij;
}

void GA::setupOptions(int argc, char *argv[], int randomSeed){

	//options.randomSeed = 429;
	std::string s = std::to_string(randomSeed);
    std::string fileName ="a4/outfile_"+s;  


	options.randomSeed = randomSeed;

	options.infile = string("infile");
	options.outfile = string(fileName);// append randomseed to output file names

    options.popSize = 200;
	options.chromLength = 52;
	options.maxgens = 500;
	options.px = 0.9;
	options.pm = 0.01f;
	options.scaler = 1.05;
	options.lambda = 2;
	options.nCriteria   = 1;

	options.mutator = Mutator::Flip;
	options.xover = Xover::UX;
	options.selector = Selector::Proportionate;

	if(argc == 4){
		options.infile = string(argv[1]);
		options.outfile = string(argv[2]);
		options.randomSeed = atoi(argv[3]);
		configure();
	}

	//derived values go after configure() above
	options.phenotypeFile   = string(options.outfile + ".pheno"); //derived from options.outfile
	//options.maxgens = options.popSize * 1.5;

    cout<<"jose";
	
    float tsp_x[400];
	float tsp_y[400];
	//float dist_matrix[GRAPH_LENGTH][GRAPH_LENGTH];
    std::ifstream input("tsplib_data/berlin52.txt");
	std::string line;
    float a, b, c; int i=1;
	while (input >> a >> b >> c){
		//std::cout<<"a: "<<a<<"\tb: "<<b<<"\tc: "<<c<<endl; 
		tsp_x[i]=b;
		tsp_y[i]=c;
        i++;
    }

    cout<<"Data from file: "<<endl;
    cout<<"City\tX\tY\n";
    for(int i=1;i<=GRAPH_LENGTH;i++){
    	cout<<i<<"\t"<<tsp_x[i]<<"\t"<<tsp_y[i]<<"\n";
    }


    for(int i=1;i<=GRAPH_LENGTH;i++){
		for(int j=1;j<=GRAPH_LENGTH;j++){
			if(i==j){
				options.dist_matrix[i][j] = 0;	
			}else{	
				options.dist_matrix[i][j] = calculateDistance(tsp_x[i],tsp_y[i],tsp_x[j],tsp_y[j]);	
			}
		}

	}

    cout<<"DIST-MATRIX At ga.cpp"<<endl;
	for(int i=1;i<=GRAPH_LENGTH;i++){
    	for(int j=1;j<=GRAPH_LENGTH;j++){
    		//cout<<matrix.dist_matrix[i][j]<<"\t";
    		cout<< options.dist_matrix[i][j]<<"\t";
    	}
    	cout<<'\n';
    }


}


